import numpy as np
import pandas as pd

def add_one(number):
    return number + 1
